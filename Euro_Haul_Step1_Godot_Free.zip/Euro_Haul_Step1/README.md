# Euro Haul — Step 1 foundation

This is a Godot-free starter project for an original truck simulator inspired by the driving-simulator genre.

## What is included
- Babylon.js 3D scene
- A simple placeholder tractor unit and trailer
- Road, lane markings, sky lighting and follow camera
- Touch steering, accelerator and brake buttons
- Capacitor Android wrapper configuration
- GitHub Actions workflow to build a debug APK

## Requirements
- Node.js 20+
- Android build tools are installed automatically by GitHub Actions
- A GitHub repository

## Run locally (optional)
```bash
npm install
npm run start
```

## Build on GitHub
1. Upload these files to the root of your repository.
2. Commit the files to the `main` branch.
3. Open the repository's **Actions** tab.
4. Select **Build Euro Haul Android APK**.
5. Press **Run workflow**.
6. When it succeeds, open the run and download `Euro-Haul-debug-APK` under Artifacts.

## Important
This is only the first technical foundation, not a complete Truckers of Europe 3 replacement. The truck is a basic placeholder model. Later steps add proper models, physics, traffic, maps, sound, menus and optimization.

The APK build workflow generates a debug APK for testing. The final installed size and performance must be measured on the target phone. A 700 MB target is a goal, not yet a verified result.
