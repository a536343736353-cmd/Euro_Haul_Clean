import * as BABYLON from "babylonjs";

const canvas = document.getElementById("renderCanvas");
const loading = document.getElementById("loading");
const engine = new BABYLON.Engine(canvas, true, {
  preserveDrawingBuffer: false,
  stencil: false,
  antialias: false,
  powerPreference: "low-power"
});

const scene = new BABYLON.Scene(engine);
scene.clearColor = new BABYLON.Color4(0.55, 0.75, 0.88, 1);
scene.collisionsEnabled = true;

const camera = new BABYLON.FollowCamera("followCamera", new BABYLON.Vector3(0, 5, -11), scene);
camera.radius = 12;
camera.heightOffset = 4;
camera.rotationOffset = 180;
camera.cameraAcceleration = 0.05;
camera.maxCameraSpeed = 10;
camera.lowerRadiusLimit = 8;
camera.upperRadiusLimit = 16;
scene.activeCamera = camera;

const sun = new BABYLON.HemisphericLight("sun", new BABYLON.Vector3(0, 1, 0), scene);
sun.intensity = 0.9;

const groundMat = new BABYLON.StandardMaterial("groundMat", scene);
groundMat.diffuseColor = new BABYLON.Color3(0.22, 0.42, 0.20);
const roadMat = new BABYLON.StandardMaterial("roadMat", scene);
roadMat.diffuseColor = new BABYLON.Color3(0.16, 0.17, 0.18);
const lineMat = new BABYLON.StandardMaterial("lineMat", scene);
lineMat.diffuseColor = new BABYLON.Color3(0.95, 0.88, 0.55);
const truckMat = new BABYLON.StandardMaterial("truckMat", scene);
truckMat.diffuseColor = new BABYLON.Color3(0.72, 0.12, 0.08);
const darkMat = new BABYLON.StandardMaterial("darkMat", scene);
darkMat.diffuseColor = new BABYLON.Color3(0.08, 0.09, 0.1);
const glassMat = new BABYLON.StandardMaterial("glassMat", scene);
glassMat.diffuseColor = new BABYLON.Color3(0.12, 0.25, 0.32);
glassMat.alpha = 0.8;

const ground = BABYLON.MeshBuilder.CreateGround("ground", {width: 100, height: 500}, scene);
ground.position.z = 150;
ground.material = groundMat;

const road = BABYLON.MeshBuilder.CreateBox("road", {width: 12, height: 0.12, depth: 500}, scene);
road.position.set(0, 0.05, 150);
road.material = roadMat;

for (let z = -90; z < 400; z += 12) {
  const dash = BABYLON.MeshBuilder.CreateBox("laneDash", {width: 0.18, height: 0.03, depth: 5}, scene);
  dash.position.set(0, 0.13, z);
  dash.material = lineMat;
}

const truck = new BABYLON.TransformNode("truck", scene);
function box(name, size, pos, mat) {
  const mesh = BABYLON.MeshBuilder.CreateBox(name, size, scene);
  mesh.position.copyFrom(pos);
  mesh.material = mat;
  mesh.parent = truck;
  return mesh;
}
box("chassis", new BABYLON.Vector3(2.2, 0.55, 4.4), new BABYLON.Vector3(0, 1.0, 0), darkMat);
box("cab", new BABYLON.Vector3(2.15, 1.8, 1.8), new BABYLON.Vector3(0, 2.0, 1.0), truckMat);
box("windscreen", new BABYLON.Vector3(1.75, 0.8, 0.08), new BABYLON.Vector3(0, 2.35, 1.92), glassMat);
box("roof", new BABYLON.Vector3(2.18, 0.15, 1.8), new BABYLON.Vector3(0, 2.95, 1.0), truckMat);
box("trailer", new BABYLON.Vector3(2.35, 2.6, 5.5), new BABYLON.Vector3(0, 2.05, -4.6), new BABYLON.StandardMaterial("trailerMat", scene));
camera.lockedTarget = truck;

const wheels = [];
for (const x of [-1.12, 1.12]) {
  for (const z of [-1.65, 0.9, 2.0]) {
    const wheel = BABYLON.MeshBuilder.CreateCylinder("wheel", {diameter: 0.85, height: 0.35, tessellation: 12}, scene);
    wheel.rotation.z = Math.PI / 2;
    wheel.position.set(x, 0.55, z);
    wheel.material = darkMat;
    wheel.parent = truck;
    wheels.push(wheel);
  }
}
truck.position.y = 0;

const input = {left: false, right: false, gas: false, brake: false};
function bindButton(id, key) {
  const el = document.getElementById(id);
  const down = e => { e.preventDefault(); input[key] = true; };
  const up = e => { e.preventDefault(); input[key] = false; };
  el.addEventListener("pointerdown", down);
  ["pointerup", "pointercancel", "pointerleave"].forEach(evt => el.addEventListener(evt, up));
}
bindButton("left", "left");
bindButton("right", "right");
bindButton("accelerate", "gas");
bindButton("brake", "brake");

let speed = 0;
let steering = 0;
scene.onBeforeRenderObservable.add(() => {
  const dt = Math.min(engine.getDeltaTime() / 1000, 0.05);
  if (input.gas) speed = Math.min(speed + 5 * dt, 18);
  else speed = Math.max(speed - 1.4 * dt, 0);
  if (input.brake) speed = Math.max(speed - 12 * dt, 0);
  const targetSteer = input.left ? -0.55 : input.right ? 0.55 : 0;
  steering += (targetSteer - steering) * Math.min(6 * dt, 1);
  truck.rotation.y += steering * speed * 0.018 * dt;
  truck.position.x += Math.sin(truck.rotation.y) * speed * dt;
  truck.position.z += Math.cos(truck.rotation.y) * speed * dt;
  truck.position.x = BABYLON.Scalar.Clamp(truck.position.x, -4.3, 4.3);
  wheels.forEach(w => w.rotation.x += speed * dt * 1.8);
});

engine.runRenderLoop(() => scene.render());
window.addEventListener("resize", () => engine.resize());
loading.style.display = "none";
